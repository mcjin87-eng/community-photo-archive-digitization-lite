# Community Photo Archive Digitization Lite: 10-Record Starter

Free Lite edition. One sheet with 10 item rows and 3 fictional examples. Records one original photo per item ID.

## Lite scope
The paid capture log, automated filename/duplicate checks, QA/handoff workflow, full field guide, and printable checklist are not included. All fields are manual.

## Use and limitations
One individual or one organization may use and adapt this file for internal work and share completed records with its own team. Do not resell or redistribute the blank template. This is a record aid, not rights clearance or preservation certification. No image files are included.

Full version: https://payhip.com/b/dKo5a
